/* global CONFIG */

((window.gitter = {}).chat = {}).options = {
  room: CONFIG.gitter.room
};
